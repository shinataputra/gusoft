# MyToko
Aplikasi manajemen toko sederhana yang bisa membantu banyak pelaku UMKM dalam menjalankan bisnis mereka dengan lebih praktis.
Aplikasi ini menawarkan berbagai fitur yang mampu meningkatkan efisiensi operasional toko secara signifikan seperti fitur tambah, ubah dan hapus barang, kemudian fitur proses pembayaran, yang dapat mempercepat proses penghitungan kembalian, memastikan tidak ada kesalahan yang dapat terjadi.
Fitur unggulan dari aplikasi ini adalah fitur kembalikan barang rusak, di mana pada fitur ini user dapat mengembalikan barang yang rusak sebelum digunakan dengan lebih mudah

# Petunjuk Penggunaan
1. Buka aplikasi terminal atau Windows powershell
2. ketik 'git' pada powershell, jika powershell menunjukkan beberapa paragraf berwarna merah, tandanya git masih belum diunduh
3. Unduh aplikasi git di https://git-scm.com/downloads
4. ikuti proses unduhan
5. setelah proses unduhan selesai, buka aplikasi melalui file manajer, klik 2 kali sampai ada pesan "Do you want to allow this app to make changes to your device" atau semacamnya, lalu klik yes
6. Git akan memunculkan pop up setup, ikuti prosedur yang diberikan oleh git. Git akan memulai proses instalasi.
7. setelah proses instalasi selesai, git akan memunculkan pop up lagi, klik tombol finish, kosongkan 2 tanda centang yang tercantum pada pop up tersebut
8. Kembali ke power shel
9. ketik cd MyToko
10. ketik python ProjekUAS2.py
11. Powershell akan membuka windows baru yang berisi aplikasi ini
12. Jika masih belum muncul, tutup lalu buka kembali aplikasi powershell dan ulangi langkah 7-8
